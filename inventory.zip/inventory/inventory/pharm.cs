﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace inventory
{
    public partial class pharm : Form
    {
        public pharm()
        {
            InitializeComponent();
        }
        private void ResetTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Text = " ";
                    else
                        func(control.Controls);
            };
            func(Controls);
        }

        private void ResetcheckBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is CheckBox)
                        (control as CheckBox).Checked = false;
                    else
                        func(control.Controls);
            };
            func(Controls);
        }

        private void EnableTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Enabled = false;
                    else
                        func(control.Controls);
            };
            func(Controls);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 q = new Form2();
            q.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ResetTextBoxes();
            ResetcheckBoxes();
            rcpt.Clear();
        }

        private void cc1_CheckedChanged(object sender, EventArgs e)
        {
            if (cc1.Checked == true)
            {
                te5.Enabled = true;
                te5.Text = "";
                te5.Focus();

            }
            else
            {
                te5.Enabled = false;
                te5.Text = "";
            }
        }

        private void cc2_CheckedChanged(object sender, EventArgs e)
        {
            if (cc2.Checked == true)
            {
                te6.Enabled = true;
                te6.Text = "";
                te6.Focus();

            }
            else
            {
                te6.Enabled = false;
                te6.Text = "";
            }
        }

        private void cc3_CheckedChanged(object sender, EventArgs e)
        {
            if (cc3.Checked == true)
            {
                te7.Enabled = true;
                te7.Text = "";
                te7.Focus();

            }
            else
            {
                te7.Enabled = false;
                te7.Text = "";
            }
        }

        private void cc4_CheckedChanged(object sender, EventArgs e)
        {
            if (cc4.Checked == true)
            {
                te8.Enabled = true;
                te8.Text = "";
                te8.Focus();

            }
            else
            {
                te8.Enabled = false;
                te8.Text = "";
            }
        }

        private void cc5_CheckedChanged(object sender, EventArgs e)
        {
            if (cc5.Checked == true)
            {
                te9.Enabled = true;
                te9.Text = "";
                te9.Focus();

            }
            else
            {
                te9.Enabled = false;
                te9.Text = "";
            }
        }

        private void cc6_CheckedChanged(object sender, EventArgs e)
        {
            if (cc6.Checked == true)
            { 
                te10.Enabled = true;
                te10.Text = "";
                te10.Focus();

            }
            else
            {
                te10.Enabled = false;
                te10.Text = "";
            }
        }

        private void cc7_CheckedChanged(object sender, EventArgs e)
        {
            if (cc7.Checked == true)
            {
                te11.Enabled = true;
                te11.Text = "";
                te11.Focus();

            }
            else
            {
                te11.Enabled = false;
                te11.Text = "";
            }
        }

        private void cc8_CheckedChanged(object sender, EventArgs e)
        {
            if (cc8.Checked == true)
            {
                te12.Enabled = true;
                te12.Text = "";
                te12.Focus();

            }
            else
            {
                te12.Enabled = false;
                te12.Text = "";
            }
        }

        private void cc9_CheckedChanged(object sender, EventArgs e)
        {
            if (cc9.Checked == true)
            {
                te13.Enabled = true;
                te13.Text = "";
                te13.Focus();

            }
            else
            {
                te13.Enabled = false;
                te13.Text = "";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double[] pharm = new double[9];

            int quanolp;
            if (cc1.Checked == false)
            {
                quanolp = 0;
            }
            else
            {
                quanolp = Convert.ToInt32(te5.Text);
            }
            pharm[0] = (quanolp * 50);

            int aaaa;
            if (cc2.Checked == false)
            {
                aaaa = 0;
            }
            else
            {
                aaaa = Convert.ToInt32(te6.Text);
            }
            pharm[1] = (aaaa * 120);

            int bbbb;
            if (cc3.Checked == false)
            {
                bbbb = 0;
            }
            else
            {
                bbbb = Convert.ToInt32(te7.Text);
            }
            pharm[2] = (bbbb * 60);

            int cccc;
            if (cc4.Checked == false)
            {
                cccc = 0;
            }
            else
            {
                cccc = Convert.ToInt32(te8.Text);
            }
            pharm[3] = (cccc * 180);

            int dddd;
            if (cc5.Checked == false)
            {
                dddd = 0;
            }
            else
            {
                dddd = Convert.ToInt32(te9.Text);
            }
            pharm[4] = (dddd * 450);

            int eeee;
            if (cc6.Checked == false)
            {
                eeee = 0;
            }
            else
            {
                eeee = Convert.ToInt32(te10.Text);
            }
            pharm[5] = (eeee * 500);

            int ffff;
            if (cc7.Checked == false)
            {
                ffff = 0;
            }
            else
            {
                ffff = Convert.ToInt32(te11.Text);
            }
            pharm[6] = (ffff * 130);

            int gggg;
            if (cc8.Checked == false)
            {
                gggg = 0;
            }
            else
            {
                gggg = Convert.ToInt32(te12.Text);
            }
            pharm[7] = (gggg * 250);

            int hhhh;
            if (cc9.Checked == false)
            {
                hhhh = 0;
            }
            else
            {
                hhhh = Convert.ToInt32(te13.Text);
            }
            pharm[8] = (hhhh * 30);

            double isubtext = pharm[0] + pharm[1] + pharm[2] + pharm[3] + pharm[4] + pharm[5] + pharm[6] + pharm[7] + pharm[8];
            te1.Text = Convert.ToString("Rs " + " " + isubtext);
            double i, j;
            i = 0.05 * isubtext;
            te2.Text = Convert.ToString("Rs " + " " + i);
            j = isubtext - i;
            te3.Text = Convert.ToString("Rs " + " " + j);

            rcpt.Clear();
            rcpt.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            rcpt.AppendText("                  HASEEB AND SONS STORE" + Environment.NewLine);
            rcpt.AppendText("                   " + dateTimePicker1.Text + "  ");
            rcpt.AppendText("CUSTOMER NAME: " + textBox1.Text + Environment.NewLine);
            rcpt.AppendText("-------------------------------------------------------------------" + Environment.NewLine);   
            rcpt.AppendText("Item                Price of product           Quantity" + Environment.NewLine);
            rcpt.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            if (cc1.Checked == true)
                rcpt.AppendText("Tablets" + "\t\t50" + "\t            " + te5.Text + Environment.NewLine);
            if (cc2.Checked == true)
                rcpt.AppendText("Syrups" + "\t\t120" + "\t            " + te6.Text + Environment.NewLine);
            if (cc3.Checked == true)
                rcpt.AppendText("Capsules" + "\t\t60" + "\t            " + te7.Text + Environment.NewLine);
            if (cc4.Checked == true)
                rcpt.AppendText("Injections" + "\t\t180" + "\t            " + te8.Text + Environment.NewLine);
            if (cc5.Checked == true)
                rcpt.AppendText("Drips" + "\t\t450" + "\t            " + te9.Text + Environment.NewLine);
            if (cc6.Checked == true)
                rcpt.AppendText("Wounds cream" + "\t500" + "\t            " + te10.Text + Environment.NewLine);
            if (cc7.Checked == true)
                rcpt.AppendText("Thermometer" + "\t130" + "\t            " + te11.Text + Environment.NewLine);
            if (cc8.Checked == true)
                rcpt.AppendText("Scissors" + "  \t\t250" + "\t            " + te12.Text + Environment.NewLine);
            if (cc9.Checked == true)
                rcpt.AppendText("Cotton" + "\t\t30" + "\t            " + te13.Text + Environment.NewLine);
            rcpt.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            rcpt.AppendText("Total : " + "\t\t" + te1.Text + Environment.NewLine);
            rcpt.AppendText("Discount: " + "\t\t" + te2.Text + Environment.NewLine);
            rcpt.AppendText("Final Amount" + "\t" + te3.Text + Environment.NewLine);
            rcpt.AppendText("------------------------THANK YOU------------------------" + Environment.NewLine);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            const string message = "Do You Want to Exit ?";
            const string closing = "Closing Program";
            var result = MessageBox.Show(message, closing, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void te5_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void te6_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void te7_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void te8_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void te9_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void te10_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void te11_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void te12_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void te13_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void label15_Click(object sender, EventArgs e)
        {
            this.Hide();
            pharmviewdata sk = new pharmviewdata();
            sk.Show();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Basit Mashkoor\Desktop\inventory\db\looooogindb.mdf;Integrated Security=True;Connect Timeout=30");
                conn.Open();
                SqlCommand sw = new SqlCommand("INSERT INTO pharm(Name,Tablets,Syrups,Capsules,Injections,Drips,Wound_cream,Thermometer,Scissors,Cotton,Total,Discount,Final_Amount,Date) VALUES ('" + textBox1.Text + "','" + te5.Text + "','" + te6.Text + "','" + te7.Text + "','" + te8.Text + "','" + te9.Text + "','" + te10.Text + "','" + te11.Text + "','" + te12.Text + "','" + te13.Text + "','" + te1.Text + "','" + te2.Text + "','" + te3.Text + "','" + dateTimePicker1.Text + "')", conn);
                if (sw.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("DATA IS INSERTED SUCCESSFULLY!!!!");
                }

                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }

}


