﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace inventory
{
    public partial class upelec : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Basit Mashkoor\Desktop\inventory\db\looooogindb.mdf;Integrated Security=True;Connect Timeout=30");

        public upelec()
        {
            InitializeComponent();
        }

        private void upelec_Load(object sender, EventArgs e)
        {
            textBox1.Text = "1";
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Basit Mashkoor\Desktop\inventory\db\looooogindb.mdf;Integrated Security=True;Connect Timeout=30");
            conn.Open();
            SqlCommand sm = new SqlCommand("SELECT * FROM elecstk WHERE Id = '" + textBox1.Text + "'", conn);

            SqlDataReader dr = sm.ExecuteReader();
            if (dr.Read())
            {
                tb5.Text = (dr["Mobile"].ToString());
                tb6.Text = (dr["Frigde"].ToString());

                tb7.Text = (dr["Washing_machine"].ToString());
                tb8.Text = (dr["Television"].ToString());
                tb9.Text = (dr["Iron"].ToString());
                tb10.Text = (dr["Oven"].ToString());
                tb11.Text = (dr["Juicer"].ToString());
                tb12.Text = (dr["Sandwitch_Maker"].ToString());
                tb13.Text = (dr["Mobile_charger"].ToString());

            }
        }

        private void button3_Click(object sender, EventArgs e)

        {
            conn.Open();
            SqlCommand sm = new SqlCommand("UPDATE elecstk SET Mobile='" + tb5.Text + "', Frigde ='" + tb6.Text + "', Washing_machine='" + tb7.Text + "', television='" + tb8.Text + "', Iron='" + tb9.Text + "', Oven='" + tb10.Text + "', Juicer='" + tb11.Text + "',Sandwitch_Maker='" + tb12.Text + "', Mobile_charger='" + tb13.Text + "' ", conn);

            if (sm.ExecuteNonQuery() == 1)
            {
                tb5.Text = "";
                tb6.Text = "";
                tb7.Text = "";
                tb8.Text = "";
                tb9.Text = "";
                tb10.Text = "";
                tb11.Text = "";
                tb12.Text = "";
                tb13.Text = "";
               
            }
            conn.Close();
            MessageBox.Show("SUCCESSFULLY UPDATED!!!");

        }

        private void button5_Click(object sender, EventArgs e)
        {

            try
            {

                SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Basit Mashkoor\Desktop\inventory\db\looooogindb.mdf;Integrated Security=True;Connect Timeout=30");
                conn.Open();
                SqlCommand sw = new SqlCommand("INSERT INTO elecstk(Id,Mobile,Frigde,Washing_machine,Television,Iron,Oven,Juicer,Sandwitch_Maker,Mobile_charger) VALUES ('" + textBox1.Text + "','" + tb5.Text + "','" + tb6.Text + "','" + tb7.Text + "','" + tb8.Text + "','" + tb9.Text + "','" + tb10.Text + "','" + tb11.Text + "','" + tb12.Text + "','" + tb13.Text + "')", conn);
                if (sw.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("DATA IS INSERTED SUCCESSFULLY!!!!");
                }

                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            elec sj = new elec();
            sj.Show();
        }
    }
}
