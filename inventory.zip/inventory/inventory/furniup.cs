﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace inventory
{
    public partial class furniup : Form
    {
        public furniup()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Basit Mashkoor\Desktop\inventory\db\looooogindb.mdf;Integrated Security=True;Connect Timeout=30");
                conn.Open();
                SqlCommand sw = new SqlCommand("INSERT INTO furstk(Id,Sofa,Cupboard,Tables,Chairs,Bed,boocase,Coatrack,Drawer,Curtains) VALUES ('" + textBox1.Text + "','" + tbx5.Text + "','" + tbx6.Text + "','" + tbx7.Text + "','" + tbx8.Text + "','" + tbx9.Text + "','" + tbx10.Text + "','" + tbx11.Text + "','" + tbx12.Text + "','" + tbx13.Text + "')", conn);
                if (sw.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("DATA IS INSERTED SUCCESSFULLY!!!!");
                }

                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            furni sb = new furni();
            sb.Show();
        }

        private void furniup_Load(object sender, EventArgs e)
        {
            textBox1.Text = "1";
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Basit Mashkoor\Desktop\inventory\db\looooogindb.mdf;Integrated Security=True;Connect Timeout=30");
            conn.Open();
            SqlCommand sm = new SqlCommand("SELECT * FROM furstk WHERE Id = '" + textBox1.Text + "'", conn);

            SqlDataReader dr = sm.ExecuteReader();
            if (dr.Read())
            {
                tbx5.Text = (dr["Sofa"].ToString());
                tbx6.Text = (dr["Cupboard"].ToString());

                tbx7.Text = (dr["Tables"].ToString());
                tbx8.Text = (dr["Chairs"].ToString());
                tbx9.Text = (dr["Bed"].ToString());
                tbx10.Text = (dr["Boocase"].ToString());
                tbx11.Text = (dr["Coatrack"].ToString());
                tbx12.Text = (dr["Drawer"].ToString());
                tbx13.Text = (dr["Curtains"].ToString());

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Basit Mashkoor\Desktop\inventory\db\looooogindb.mdf;Integrated Security=True;Connect Timeout=30");
            conn.Open();
            SqlCommand sm = new SqlCommand("UPDATE furstk SET Sofa='" + tbx5.Text + "', Cupboard ='" + tbx6.Text + "', Tables='" + tbx7.Text + "', Chairs='" + tbx8.Text + "', Bed='" + tbx9.Text + "', Boocase='" + tbx10.Text + "', Coatrack='" + tbx11.Text + "',Drawer='" + tbx12.Text + "', Curtains='" + tbx13.Text + "' ", conn);

            if (sm.ExecuteNonQuery() == 1)
            {
                tbx5.Text = "";
                tbx6.Text = "";
                tbx7.Text = "";
                tbx8.Text = "";
                tbx9.Text = "";
                tbx10.Text = "";
                tbx11.Text = "";
                tbx12.Text = "";
                tbx13.Text = "";

            }
            conn.Close();
            MessageBox.Show("SUCCESSFULLY UPDATED!!!");

        }
    }
}
