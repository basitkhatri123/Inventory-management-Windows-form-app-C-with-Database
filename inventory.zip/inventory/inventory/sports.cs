﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace inventory
{
    public partial class sports : Form
    {
        public sports()
        {
            InitializeComponent();
        }
        private void ResetTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Text = " ";
                    else
                        func(control.Controls);
            };
            func(Controls);
        }

        private void ResetcheckBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is CheckBox)
                        (control as CheckBox).Checked = false;
                    else
                        func(control.Controls);
            };
            func(Controls);
        }

        private void EnableTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Enabled = false;
                    else
                        func(control.Controls);
            };
            func(Controls);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 g = new Form2();
            g.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ResetTextBoxes();
            ResetcheckBoxes();
            rtc.Clear();
        }

        private void ck1_CheckedChanged(object sender, EventArgs e)
        {
            if (ck1.Checked == true)
            {
                tx5.Enabled = true;
                tx5.Text = "";
                tx5.Focus();

            }
            else
            {
                tx5.Enabled = false;
                tx5.Text = "";
            }
        }

        private void ck2_CheckedChanged(object sender, EventArgs e)
        {
            if (ck2.Checked == true)
            {
                tx6.Enabled = true;
                tx6.Text = "";
                tx6.Focus();

            }
            else
            {
                tx6.Enabled = false;
                tx6.Text = "";
            }
        }

        private void ck3_CheckedChanged(object sender, EventArgs e)
        {
            if (ck3.Checked == true)
            {
                tx7.Enabled = true;
                tx7.Text = "";
                tx7.Focus();

            }
            else
            {
                tx7.Enabled = false;
                tx7.Text = "";
            }
        }

        private void ck4_CheckedChanged(object sender, EventArgs e)
        {
            if (ck4.Checked == true)
            {
                tx8.Enabled = true;
                tx8.Text = "";
                tx8.Focus();

            }
            else
            {
                tx8.Enabled = false;
                tx8.Text = "";
            }
        }

        private void ck5_CheckedChanged(object sender, EventArgs e)
        {
            if (ck5.Checked == true)
            {
                tx9.Enabled = true;
                tx9.Text = "";
                tx9.Focus();

            }
            else
            {
                tx9.Enabled = false;
                tx9.Text = "";
            }
        }

        private void ck6_CheckedChanged(object sender, EventArgs e)
        {
            if (ck6.Checked == true)
            {
                tx10.Enabled = true;
                tx10.Text = "";
                tx10.Focus();

            }
            else
            {
                tx10.Enabled = false;
                tx10.Text = "";
            }
        }

        private void ck7_CheckedChanged(object sender, EventArgs e)
        {
            if (ck7.Checked == true)
            {
                tx11.Enabled = true;
                tx11.Text = "";
                tx11.Focus();

            }
            else
            {
                tx11.Enabled = false;
                tx11.Text = "";
            }
        }

        private void ck8_CheckedChanged(object sender, EventArgs e)
        {
            if (ck8.Checked == true)
            {
                tx12.Enabled = true;
                tx12.Text = "";
                tx12.Focus();

            }
            else
            {
                tx12.Enabled = false;
                tx12.Text = "";
            }
        }

        private void ck9_CheckedChanged(object sender, EventArgs e)
        {
            if (ck9.Checked == true)
            {
                tx13.Enabled = true;
                tx13.Text = "";
                tx13.Focus();

            }
            else
            {
                tx13.Enabled = false;
                tx13.Text = "";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double[] spor = new double[9];

            int quanolp;
            if (ck1.Checked == false)
            {
                quanolp = 0;
            }
            else
            {
                quanolp = Convert.ToInt32(tx5.Text);
            }
            spor[0] = (quanolp * 15000);

            int aaaa;
            if (ck2.Checked == false)
            {
                aaaa = 0;
            }
            else
            {
                aaaa = Convert.ToInt32(tx6.Text);
            }
            spor[1] = (aaaa * 8000);

            int bbbb;
            if (ck3.Checked == false)
            {
                bbbb = 0;
            }
            else
            {
                bbbb = Convert.ToInt32(tx7.Text);
            }
            spor[2] = (bbbb * 17000);

            int cccc;
            if (ck4.Checked == false)
            {
                cccc = 0;
            }
            else
            {
                cccc = Convert.ToInt32(tx8.Text);
            }
            spor[3] = (cccc * 7000);

            int dddd;
            if (ck5.Checked == false)
            {
                dddd = 0;
            }
            else
            {
                dddd = Convert.ToInt32(tx9.Text);
            }
            spor[4] = (dddd * 10000);

            int eeee;
            if (ck6.Checked == false)
            {
                eeee = 0;
            }
            else
            {
                eeee = Convert.ToInt32(tx10.Text);
            }
            spor[5] = (eeee * 7500);

            int ffff;
            if (ck7.Checked == false)
            {
                ffff = 0;
            }
            else
            {
                ffff = Convert.ToInt32(tx11.Text);
            }
            spor[6] = (ffff * 23000);

            int gggg;
            if (ck8.Checked == false)
            {
                gggg = 0;
            }
            else
            {
                gggg = Convert.ToInt32(tx12.Text);
            }
            spor[7] = (gggg * 13000);

            int hhhh;
            if (ck9.Checked == false)
            {
                hhhh = 0;
            }
            else
            {
                hhhh = Convert.ToInt32(tx13.Text);
            }
            spor[8] = (hhhh * 29000);

            double isubtext = spor[0] + spor[1] + spor[2] + spor[3] + spor[4] + spor[5] + spor[6] + spor[7] + spor[8];
            tx1.Text = Convert.ToString("Rs " + " " + isubtext);
            double i, j;
            i = 0.05 * isubtext;
            tx2.Text = Convert.ToString("Rs " + " " + i);
            j = isubtext - i;
            tx3.Text = Convert.ToString("Rs " + " " + j);

            rtc.Clear();
            rtc.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            rtc.AppendText("                  HASEEB AND SONS STORE" + Environment.NewLine);
            rtc.AppendText("                   " + dateTimePicker1.Text + "  ");
            rtc.AppendText("CUSTOMER NAME: " + textBox1.Text + Environment.NewLine);
            rtc.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            rtc.AppendText("Item                Price of product           Quantity" + Environment.NewLine);
            rtc.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            if (ck1.Checked == true)
                rtc.AppendText("Cricket Equip" + "\t15000" + "\t            " + tx5.Text + Environment.NewLine);
            if (ck2.Checked == true)
                rtc.AppendText("Badminton Equip" + "\t8000" + "\t            " + tx6.Text + Environment.NewLine);
            if (ck3.Checked == true)
                rtc.AppendText("Baseball Equip" + "\t17000" + "\t            " + tx7.Text + Environment.NewLine);
            if (ck4.Checked == true)
                rtc.AppendText("Basketball Equip" + "\t7000" + "\t            " + tx8.Text + Environment.NewLine);
            if (ck5.Checked == true)
                rtc.AppendText("Swimming Equip" + "\t10000" + "\t            " + tx9.Text + Environment.NewLine);
            if (ck6.Checked == true)
                rtc.AppendText("Tennis Equip" + "\t7500" + "\t            " + tx10.Text + Environment.NewLine);
            if (ck7.Checked == true)
                rtc.AppendText("Football Equip" + "\t23000" + "\t            " + tx11.Text + Environment.NewLine);
            if (ck8.Checked == true)
                rtc.AppendText("Rugby Equip" + "  \t13000" + "\t            " + tx12.Text + Environment.NewLine);
            if (ck9.Checked == true)
                rtc.AppendText("Golf Equip" + "\t\t29000" + "\t            " + tx13.Text + Environment.NewLine);
            rtc.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            rtc.AppendText("Total : " + "\t\t" + tx1.Text + Environment.NewLine);
            rtc.AppendText("Discount: " + "\t\t" + tx2.Text + Environment.NewLine);
            rtc.AppendText("Final Amount" + "\t" + tx3.Text + Environment.NewLine);
            rtc.AppendText("------------------------THANK YOU------------------------" + Environment.NewLine);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            const string message = "Do You Want to Exit ?";
            const string closing = "Closing Program";
            var result = MessageBox.Show(message, closing, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void tx5_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tx6_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tx7_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tx8_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tx9_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tx10_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tx11_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tx12_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tx13_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void label15_Click(object sender, EventArgs e)
        {
            this.Hide();
            sportviewdata sx = new sportviewdata();
            sx.Show();

                
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Basit Mashkoor\Desktop\inventory\db\looooogindb.mdf;Integrated Security=True;Connect Timeout=30");
                conn.Open();
                SqlCommand sw = new SqlCommand("INSERT INTO Spor(Name,Cricket_Eqp,Badminton_Eqp,Baseball_Eqp,Basketball_Eqp,Swimming_Eqp,Tennis_Eqp,Football_Eqp,Rugby_Eqp,Golf_Eqp,Total,Discount,Final_Amount,Date) VALUES ('" + textBox1.Text + "','" + tx5.Text + "','" + tx6.Text + "','" + tx7.Text + "','" + tx8.Text + "','" + tx9.Text + "','" + tx10.Text + "','" + tx11.Text + "','" + tx12.Text + "','" + tx13.Text + "','" + tx1.Text + "','" + tx2.Text + "','" + tx3.Text + "','" + dateTimePicker1.Text + "')", conn);
                if (sw.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("DATA IS INSERTED SUCCESSFULLY!!!!");
                }

                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
