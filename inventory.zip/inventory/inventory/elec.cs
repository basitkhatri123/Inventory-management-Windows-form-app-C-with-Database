﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace inventory
{
    public partial class elec : Form
    {
        

        public elec()
        {
            InitializeComponent();
        }
       
        private void ResetTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Text = " ";
                    else
                        func(control.Controls);
            };
            func(Controls);
        }

        private void ResetcheckBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is CheckBox)
                        (control as CheckBox).Checked = false;
                    else
                        func(control.Controls);
            };
            func(Controls);
        }

        private void EnableTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Enabled = false;
                    else
                        func(control.Controls);
            };
            func(Controls);
        }


        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 s = new Form2();
            s.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ResetTextBoxes();
            ResetcheckBoxes();
            receipt.Clear();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            

                if (cb1.Checked == true)
            {
                tb5.Enabled = true;
                tb5.Text = "";
                tb5.Focus();

            }
            else
            {
                tb5.Enabled = false;
                tb5.Text = "";
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (cb2.Checked == true)
            {
                tb6.Enabled = true;
                tb6.Text = "";
                tb6.Focus();

            }
            else
            {
                tb6.Enabled = false;
                tb6.Text = "";
            }
        }

        private void cb3_CheckedChanged(object sender, EventArgs e)
        {
            if (cb3.Checked == true)
            {
                tb7.Enabled = true;
                tb7.Text = "";
                tb7.Focus();
            
            }
            else
            {
                tb7.Enabled = false;
                tb7.Text = "";
            }
        }

        private void cb4_CheckedChanged(object sender, EventArgs e)
        {
            if (cb4.Checked == true)
            {
                tb8.Enabled = true;
                tb8.Text = "";
                tb8.Focus();

            }
            else
            {
                tb8.Enabled = false;
                tb8.Text = "";
            }
        }

        private void cb5_CheckedChanged(object sender, EventArgs e)
        {
            if (cb5.Checked == true)
            {
                tb9.Enabled = true;
                tb9.Text = "";
                tb9.Focus();

            }
            else
            {
                tb9.Enabled = false;
                tb9.Text = "";
            }
        }

        private void cb6_CheckedChanged(object sender, EventArgs e)
        {
            if (cb6.Checked == true)
            {
                tb10.Enabled = true;
                tb10.Text = "";
                tb10.Focus();

            }
            else
            {
                tb10.Enabled = false;
                tb10.Text = "";
            }
        }

        private void cb7_CheckedChanged(object sender, EventArgs e)
        {
            if (cb7.Checked == true)
            {
                tb11.Enabled = true;
                tb11.Text = "";
                tb11.Focus();

            }
            else
            {
                tb11.Enabled = false;
                tb11.Text = "";
            }
        }

        private void cb8_CheckedChanged(object sender, EventArgs e)
        {
            if (cb8.Checked == true)
            {
                tb12.Enabled = true;
                tb12.Text = "";
                tb12.Focus();

            }
            else
            {
                tb12.Enabled = false;
                tb12.Text = "";
            }
        }

        private void cb9_CheckedChanged(object sender, EventArgs e)
        {
             if(cb9.Checked == true)
            {
                tb13.Enabled = true;
                tb13.Text = "";
                tb13.Focus();

            }

            else
            {
                tb13.Enabled = false;
                tb13.Text = "";
            }
       }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Basit Mashkoor\Desktop\inventory\db\looooogindb.mdf;Integrated Security=True;Connect Timeout=30");
            

            double[] basit = new double[9];

            int quanolp;
            if (cb1.Checked == false)
            {
                quanolp = 0;
            }
            else
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM elecstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string mob = (dr["Mobile"].ToString());
                    quanolp = Convert.ToInt32(tb5.Text);
                    basit[0] = (quanolp * Convert.ToInt64(mob));
                }
                conn.Close();
            }
            

            int aaaa;
            if (cb2.Checked == false)
            {
                aaaa = 0;
            }
            else
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM elecstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string fri = (dr["Frigde"].ToString());
                    aaaa = Convert.ToInt32(tb6.Text);
                    basit[1] = (aaaa * Convert.ToInt64(fri));
                }
                conn.Close();
            }
            

            int bbbb;
            if (cb3.Checked == false)
            {
                bbbb = 0;
            }
            else
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM elecstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string was = (dr["Washing_machine"].ToString());
                    bbbb = Convert.ToInt32(tb7.Text);
                    basit[2] = (bbbb * Convert.ToInt64(was));
                }
                conn.Close();
            }
            

            int cccc;
            if (cb4.Checked == false)
            {
                cccc = 0;
            }
            else
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM elecstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string tele = (dr["Television"].ToString());
                    cccc = Convert.ToInt32(tb8.Text);
                    basit[3] = (cccc * Convert.ToInt64(tele));
                }
                conn.Close();
            }
          

            int dddd;
            if (cb5.Checked == false)
            {
                dddd = 0;
            }
            else
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM elecstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string iro = (dr["Iron"].ToString());
                    dddd = Convert.ToInt32(tb9.Text);
                    basit[4] = (dddd * Convert.ToInt64(iro));
                }
                conn.Close();
            }
            

            int eeee;
            if (cb6.Checked == false)
            {
                eeee = 0;
            }
            else
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM elecstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string ove = (dr["Oven"].ToString());
                    eeee = Convert.ToInt32(tb10.Text);
                    basit[5] = (eeee * Convert.ToInt64(ove));
                }
                conn.Close();
            }
            

            int ffff;
            if (cb7.Checked == false)
            {
                ffff = 0;
            }
            else
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM elecstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string jui = (dr["Juicer"].ToString());
                   ffff = Convert.ToInt32(tb11.Text);
                    basit[6] = (ffff * Convert.ToInt64(jui));
                }
                conn.Close();
            }
            

            int gggg;
            if (cb8.Checked == false)
            {
                gggg = 0;
            }
            else
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM elecstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string sand = (dr["Sandwitch_Maker"].ToString());
                    gggg = Convert.ToInt32(tb12.Text);
                    basit[7] = (gggg * Convert.ToInt64(sand));
                }
                conn.Close();
            }
           

            int hhhh;
            if (cb9.Checked == false)
            {
                hhhh = 0;
            }
            else
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM elecstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string mobi = (dr["Mobile_charger"].ToString());
                    hhhh = Convert.ToInt32(tb13.Text);
                    basit[8] = (hhhh * Convert.ToInt64(mobi));
                }
                conn.Close();
            }
          

            double isubtext = basit[0] + basit[1] + basit[2] + basit[3] + basit[4] + basit[5] + basit[6] + basit[7] + basit[8];
            tb1.Text = Convert.ToString("Rs " + " " + isubtext);
            double i, j;
            i = 0.05 * isubtext;
            tb2.Text = Convert.ToString("Rs " + " " + i);
            j = isubtext - i;
            tb3.Text = Convert.ToString("Rs " + " " + j);

            receipt.Clear();
            // receipt.AppendText(Environment.NewLine);
            receipt.AppendText(" -----------------------------------------------------------------" + Environment.NewLine);
            receipt.AppendText("\t" + "   HASEEB AND SONS STORE" + Environment.NewLine);
            receipt.AppendText("                    " + dateTimePicker1.Text + "  ");
            receipt.AppendText("CUSTOMER NAME: " + textBox1.Text + Environment.NewLine);
            receipt.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            receipt.AppendText("Item                  Price Of Product           Quantity" + Environment.NewLine);
            receipt.AppendText("-------------------------------------------------------------------" + Environment.NewLine);

            if (cb1.Checked == true)
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM elecstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string mob = (dr["Mobile"].ToString());
                    receipt.AppendText("Mobile                         "+ mob + "\t            " + tb5.Text + Environment.NewLine);
                }
                conn.Close();
            }
            if (cb2.Checked == true)
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM elecstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string fri = (dr["Frigde"].ToString());
                    receipt.AppendText("Fridge                          " +fri+ "\t            " + tb6.Text + Environment.NewLine);
                }
                conn.Close();
            }
            if (cb3.Checked == true)
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM elecstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string wash = (dr["Washing_machine"].ToString());
                    receipt.AppendText("Washing Machine       " + wash + "\t            " + tb7.Text + Environment.NewLine);
                }
                conn.Close();
            }
            if (cb4.Checked == true)
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM elecstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string tele = (dr["Television"].ToString());
                    receipt.AppendText("Television                    " + tele + "\t            " + tb8.Text + Environment.NewLine);
                }
                conn.Close();
            }
            if (cb5.Checked == true)
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM elecstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string iro = (dr["Iron"].ToString());
                    receipt.AppendText("Iron                              " + iro + "\t            " + tb9.Text + Environment.NewLine);
                }
                conn.Close();
            }
            if (cb6.Checked == true)
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM elecstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string ove = (dr["Oven"].ToString());
                    receipt.AppendText("Oven                            " + ove + "\t            " + tb10.Text + Environment.NewLine);
                }
                conn.Close();
            }
            if (cb7.Checked == true)
                {
                    conn.Open();
                    SqlCommand sc = new SqlCommand("SELECT * FROM elecstk", conn);
                    sc.ExecuteNonQuery();
                    SqlDataReader dr = sc.ExecuteReader();
                    if (dr.Read())
                    {
                        string jui = (dr["Juicer"].ToString());
                        receipt.AppendText("Juicer                           " + jui + "\t            " + tb11.Text + Environment.NewLine);
                    } 
                conn.Close();
            }
            if (cb8.Checked == true)
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM elecstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string sand = (dr["Sandwitch_Maker"].ToString());
                    receipt.AppendText("Sandwitch_Maker       " +sand + "\t            " + tb12.Text + Environment.NewLine);
                }
                conn.Close();
            }
            if (cb9.Checked == true)
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM elecstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string mobi = (dr["Mobile_charger"].ToString());
                    receipt.AppendText("Mobile_charger           " + mobi + "\t            " + tb12.Text + Environment.NewLine);
                }
                conn.Close();

            }

            receipt.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            receipt.AppendText("Total: " + "\t\t" + tb1.Text + Environment.NewLine);
            receipt.AppendText("Discount: " + "\t\t" + tb2.Text + Environment.NewLine);
            receipt.AppendText("Final Amount: " + "\t" + tb3.Text + Environment.NewLine);

            receipt.AppendText("\n------------------------Thank You--------------------------" + Environment.NewLine);
            
            


        }

        private void button4_Click(object sender, EventArgs e)
        {
            const string message = "Do You Want to Exit ?";
            const string closing = "Closing Program";
            var result = MessageBox.Show(message, closing, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void tb5_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if(!char.IsDigit(ch) && ch!=8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
            
        }

        private void tb6_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tb7_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tb8_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tb9_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tb10_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tb11_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tb12_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tb13_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void label15_Click(object sender, EventArgs e)
        {
            this.Hide();
            elecviewdata sd = new elecviewdata();
            sd.Show();
        }

       

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form2 st = new Form2();
            st.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
            try
            {
                
                SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Basit Mashkoor\Desktop\inventory\db\looooogindb.mdf;Integrated Security=True;Connect Timeout=30");
                conn.Open();
                SqlCommand sw = new SqlCommand("INSERT INTO elct(Name,Mobile,Fridge,Washing_Machine,Television,Iron,Oven,Juicer,Sandwitch_Maker,Mobile_Charger,Total,Discount,Total_Amount,Date) VALUES ('" + textBox1.Text + "','" + tb5.Text + "','" + tb6.Text + "','" + tb7.Text + "','" + tb8.Text + "','" + tb9.Text + "','" + tb10.Text + "','" + tb11.Text + "','" + tb12.Text + "','" + tb13.Text + "','" + tb1.Text + "','" + tb2.Text + "','" + tb3.Text + "','"+dateTimePicker1.Text+"')", conn);
                if (sw.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("DATA IS INSERTED SUCCESSFULLY!!!!");
                }

                conn.Close();
            }
            catch( Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label17_Click(object sender, EventArgs e)
        {
            this.Hide();
            upelec sn = new upelec();
            sn.Show();

        }

       
    }


}

 


    

