﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace inventory
{
    public partial class wardro : Form
    {
        public wardro()
        {
            InitializeComponent();
        }
        private void ResetTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Text = " ";
                    else
                        func(control.Controls);
            };
            func(Controls);
        }

        private void ResetcheckBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is CheckBox)
                        (control as CheckBox).Checked = false;
                    else
                        func(control.Controls);
            };
            func(Controls);
        }

        private void EnableTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Enabled = false;
                    else
                        func(control.Controls);
            };
            func(Controls);
        }


        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 k = new Form2();
            k.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ResetTextBoxes();
            ResetcheckBoxes();
            rtcc.Clear();
        }

        private void c1_CheckedChanged(object sender, EventArgs e)
        {
            if (c1.Checked == true)
            {
                txb5.Enabled = true;
                txb5.Text = "";
                txb5.Focus();

            }
            else
            {
                txb5.Enabled = false;
                txb5.Text = "";
            }
        }

        private void c2_CheckedChanged(object sender, EventArgs e)
        {
            if (c2.Checked == true)
            {
                txb6.Enabled = true;
                txb6.Text = "";
                txb6.Focus();

            }
            else
            {
                txb6.Enabled = false;
                txb6.Text = "";
            }
        }

        private void c3_CheckedChanged(object sender, EventArgs e)
        {
            if (c3.Checked == true)
            {
                txb7.Enabled = true;
                txb7.Text = "";
                txb7.Focus();

            }
            else
            {
                txb7.Enabled = false;
                txb7.Text = "";
            }
        }

        private void c4_CheckedChanged(object sender, EventArgs e)
        {
            if (c4.Checked == true)
            {
                txb8.Enabled = true;
                txb8.Text = "";
                txb8.Focus();

            }
            else
            {
                txb8.Enabled = false;
                txb8.Text = "";
            }
        }

        private void c5_CheckedChanged(object sender, EventArgs e)
        {
            if (c5.Checked == true)
            {
                txb9.Enabled = true;
                txb9.Text = "";
                txb9.Focus();

            }
            else
            {
                txb9.Enabled = false;
                txb9.Text = "";
            }
        }

        private void c6_CheckedChanged(object sender, EventArgs e)
        {
            if (c6.Checked == true)
            {
                txb10.Enabled = true;
                txb10.Text = "";
                txb10.Focus();

            }
            else
            {
                txb10.Enabled = false;
                txb10.Text = "";
            }
        }

        private void c7_CheckedChanged(object sender, EventArgs e)
        {
            if (c7.Checked == true)
            {
                txb11.Enabled = true;
                txb11.Text = "";
                txb11.Focus();

            }
            else
            {
                txb11.Enabled = false;
                txb11.Text = "";
            }
        }

        private void c8_CheckedChanged(object sender, EventArgs e)
        {
            if (c8.Checked == true)
            {
                txb12.Enabled = true;
                txb12.Text = "";
                txb12.Focus();

            }
            else
            {
                txb12.Enabled = false;
                txb12.Text = "";
            }
        }

        private void c9_CheckedChanged(object sender, EventArgs e)
        {
            if (c9.Checked == true)
            {
                txb13.Enabled = true;
                txb13.Text = "";
                txb13.Focus();

            }
            else
            {
                txb13.Enabled = false;
                txb13.Text = "";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double[] ward = new double[9];

            int quanolp;
            if (c1.Checked == false)
            {
                quanolp = 0;
            }
            else
            {
                quanolp = Convert.ToInt32(txb5.Text);
            }
            ward[0] = (quanolp * 2200);

            int aaaa;
            if (c2.Checked == false)
            {
                aaaa = 0;
            }
            else
            {
                aaaa = Convert.ToInt32(txb6.Text);
            }
            ward[1] = (aaaa * 3000);

            int bbbb;
            if (c3.Checked == false)
            {
                bbbb = 0;
            }
            else
            {
                bbbb = Convert.ToInt32(txb7.Text);
            }
            ward[2] = (bbbb * 2300);

            int cccc;
            if (c4.Checked == false)
            {
                cccc = 0;
            }
            else
            {
                cccc = Convert.ToInt32(txb8.Text);
            }
            ward[3] = (cccc * 2700);

            int dddd;
            if (c5.Checked == false)
            {
                dddd = 0;
            }
            else
            {
                dddd = Convert.ToInt32(txb9.Text);
            }
            ward[4] = (dddd * 1300);

            int eeee;
            if (c6.Checked == false)
            {
                eeee = 0;
            }
            else
            {
                eeee = Convert.ToInt32(txb10.Text);
            }
            ward[5] = (eeee * 1500);

            int ffff;
            if (c7.Checked == false)
            {
                ffff = 0;
            }
            else
            {
                ffff = Convert.ToInt32(txb11.Text);
            }
            ward[6] = (ffff * 2900);

            int gggg;
            if (c8.Checked == false)
            {
                gggg = 0;
            }
            else
            {
                gggg = Convert.ToInt32(txb12.Text);
            }
            ward[7] = (gggg * 800);

            int hhhh;
            if (c9.Checked == false)
            {
                hhhh = 0;
            }
            else
            {
                hhhh = Convert.ToInt32(txb13.Text);
            }
            ward[8] = (hhhh * 1000);

            double isubtext = ward[0] + ward[1] + ward[2] + ward[3] + ward[4] + ward[5] + ward[6] + ward[7] + ward[8];
            txb1.Text = Convert.ToString("Rs " + " " + isubtext);
            double i, j;
            i = 0.05 * isubtext;
            txb2.Text = Convert.ToString("Rs " + " " + i);
            j = isubtext - i;
            txb3.Text = Convert.ToString("Rs " + " " + j);

            rtcc.Clear();
            rtcc.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            rtcc.AppendText("                  HASEEB AND SONS STORE" + Environment.NewLine);
            rtcc.AppendText("                   " + dateTimePicker1.Text);
            rtcc.AppendText("CUSTOMER NAME: " + textBox1.Text + Environment.NewLine);
            rtcc.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            rtcc.AppendText("Item                Price of product           Quantity" + Environment.NewLine);
            rtcc.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            if (c1.Checked == true)
                rtcc.AppendText("Men's K|S" + "\t\t2200" + "\t            " + txb5.Text + Environment.NewLine);
            if (c2.Checked == true)
                rtcc.AppendText("Women's K|S" + "\t3000" + "\t            " + txb6.Text + Environment.NewLine);
            if (c3.Checked == true)
                rtcc.AppendText("Men's P|S" + "\t\t2300" + "\t            " + txb7.Text + Environment.NewLine);
            if (c4.Checked == true)
                rtcc.AppendText("Womes's P|S" + "\t2700" + "\t            " + txb8.Text + Environment.NewLine);
            if (c5.Checked == true)
                rtcc.AppendText("Baby boy dress" + "\t1300" + "\t            " + txb9.Text + Environment.NewLine);
            if (c6.Checked == true)
                rtcc.AppendText("Baby girl dress" + "\t1500" + "\t            " + txb10.Text + Environment.NewLine);
            if (c7.Checked == true)
                rtcc.AppendText("Shoes|Sandals" + "\t2900" + "\t            " + txb11.Text + Environment.NewLine);
            if (c8.Checked == true)
                rtcc.AppendText("Hats" + "  \t\t800" + "\t            " + txb12.Text + Environment.NewLine);
            if (c9.Checked == true)
                rtcc.AppendText("Glasses" + "\t\t1000" + "\t            " + txb13.Text + Environment.NewLine);
            rtcc.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            rtcc.AppendText("Total : " + "\t\t" + txb1.Text + Environment.NewLine);
            rtcc.AppendText("Discount: " + "\t\t" + txb2.Text + Environment.NewLine);
            rtcc.AppendText("Final Amount" + "\t" + txb3.Text + Environment.NewLine);
            rtcc.AppendText("------------------------THANK YOU------------------------" + Environment.NewLine);
        
        }

        private void button4_Click(object sender, EventArgs e)
        {
            const string message = "Do You Want to Exit ?";
            const string closing = "Closing Program";
            var result = MessageBox.Show(message, closing, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void txb5_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void txb6_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void txb7_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txb8_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void txb9_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void txb10_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void txb11_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void txb12_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void txb13_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void label15_Click(object sender, EventArgs e)
        {
            this.Hide();
            wardviewdata sl = new wardviewdata();
            sl.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Basit Mashkoor\Desktop\inventory\db\looooogindb.mdf;Integrated Security=True;Connect Timeout=30");
                conn.Open();
                SqlCommand sw = new SqlCommand("INSERT INTO ward(Name,Mens_kurta,Womens_kurti,Mens_pant_shirts,Womens_pant_shirts,Baby_boy_dress,Baby_girl_dress,Shoes_Sandals,Hats,Glasses,Total,Discount,Final_Amount,Date) VALUES ('" + textBox1.Text + "','" + txb5.Text + "','" + txb6.Text + "','" + txb7.Text + "','" + txb8.Text + "','" + txb9.Text + "','" + txb10.Text + "','" + txb11.Text + "','" + txb12.Text + "','" + txb13.Text + "','" + txb1.Text + "','" + txb2.Text + "','" + txb3.Text + "','" + dateTimePicker1.Text + "')", conn);
                if (sw.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("DATA IS INSERTED SUCCESSFULLY!!!!");
                }

                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
