﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace inventory
{
    public partial class furni : Form
    {
        public furni()
        {
            InitializeComponent();
        }
        private void ResetTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Text = " ";
                    else
                        func(control.Controls);
            };
            func(Controls);
        }

        private void ResetcheckBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is CheckBox)
                        (control as CheckBox).Checked = false;
                    else
                        func(control.Controls);
            };
            func(Controls);
        }

        private void EnableTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Enabled = false;
                    else
                        func(control.Controls);
            };
            func(Controls);
        }


        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f = new Form2();
            f.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ResetTextBoxes();
            ResetcheckBoxes();
            receipt.Clear();
        }

        private void cbk1_CheckedChanged(object sender, EventArgs e)
        {

            if (cbk1.Checked == true)
            {
                tbx5.Enabled = true;
                tbx5.Text = "";
                tbx5.Focus();

            }
            else
            {
                tbx5.Enabled = false;
                tbx5.Text = "";
            }
        }

        private void cbk2_CheckedChanged(object sender, EventArgs e)
        {

            if (cbk2.Checked == true)
            {
                tbx6.Enabled = true;
                tbx6.Text = "";
                tbx6.Focus();

            }
            else
            {
                tbx6.Enabled = false;
                tbx6.Text = "";
            }
        }

        private void cbk3_CheckedChanged(object sender, EventArgs e)
        {

            if (cbk3.Checked == true)
            {
                tbx7.Enabled = true;
                tbx7.Text = "";
                tbx7.Focus();

            }
            else
            {
                tbx7.Enabled = false;
                tbx7.Text = "";
            }
        }

        private void cbk4_CheckedChanged(object sender, EventArgs e)
        {
            if (cbk4.Checked == true)
            {
                tbx8.Enabled = true;
                tbx8.Text = "";
                tbx8.Focus();

            }
            else
            {
                tbx8.Enabled = false;
                tbx8.Text = "";
            }
        }

        private void cbk5_CheckedChanged(object sender, EventArgs e)
        {
            if (cbk5.Checked == true)
            {
                tbx9.Enabled = true;
                tbx9.Text = "";
                tbx9.Focus();

            }
            else
            {
                tbx9.Enabled = false;
                tbx9.Text = "";
            }
        }

        private void cbk6_CheckedChanged(object sender, EventArgs e)
        {
            if (cbk6.Checked == true)
            {
                tbx10.Enabled = true;
                tbx10.Text = "";
                tbx10.Focus();

            }
            else
            {
                tbx10.Enabled = false;
                tbx10.Text = "";
            }
        }

        private void cbk7_CheckedChanged(object sender, EventArgs e)
        {
            if (cbk7.Checked == true)
            {
                tbx11.Enabled = true;
                tbx11.Text = "";
                tbx11.Focus();

            }
            else
            {
                tbx11.Enabled = false;
                tbx11.Text = "";
            }
        }

        private void cbk8_CheckedChanged(object sender, EventArgs e)
        {
            if (cbk8.Checked == true)
            {
                tbx12.Enabled = true;
                tbx12.Text = "";
                tbx12.Focus();

            }
            else
            {
                tbx12.Enabled = false;
                tbx12.Text = "";
            }
        }

        private void cbk9_CheckedChanged(object sender, EventArgs e)
        {
            if (cbk9.Checked == true)
            {
                tbx13.Enabled = true;
                tbx13.Text = "";
                tbx13.Focus();

            }
            else
            {
                tbx13.Enabled = false;
                tbx13.Text = "";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Basit Mashkoor\Desktop\inventory\db\looooogindb.mdf;Integrated Security=True;Connect Timeout=30");
            double[] furn = new double[9];

            int quanolp;
            if (cbk1.Checked == false)
            {
                quanolp = 0;
            }
            else
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM furstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string sof = (dr["Sofa"].ToString());
                    quanolp = Convert.ToInt32(tbx5.Text);
                    furn[0] = (quanolp * Convert.ToInt64(sof));
                }
                conn.Close();
            }
            

            int aaaa;
            if (cbk2.Checked == false)
            {
                aaaa = 0;
            }
            else
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM furstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string cup = (dr["Cupboard"].ToString());
                    aaaa = Convert.ToInt32(tbx6.Text);
                    furn[1] = (aaaa * Convert.ToInt64(cup));
                }
                conn.Close();
            }
            

            int bbbb;
            if (cbk3.Checked == false)
            {
                bbbb = 0;
            }
            else
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM furstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string tab = (dr["Tables"].ToString());
                    bbbb = Convert.ToInt32(tbx7.Text);
                    furn[2] = (bbbb * Convert.ToInt64(tab));
                }
                conn.Close();
            }
            

            int cccc;
            if (cbk4.Checked == false)
            {
                cccc = 0;
            }
            else
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM furstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string cha = (dr["Chairs"].ToString());
                    cccc = Convert.ToInt32(tbx8.Text);
                    furn[3] = (cccc * Convert.ToInt64(cha));
                }
                conn.Close();
            }
            

            int dddd;
            if (cbk5.Checked == false)
            {
                dddd = 0;
            }
            else
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM furstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string be = (dr["Bed"].ToString());
                   dddd = Convert.ToInt32(tbx9.Text);
                    furn[4] = (dddd * Convert.ToInt64(be));
                }
                conn.Close();
            }
            

            int eeee;
            if (cbk6.Checked == false)
            {
                eeee = 0;
            }
            else
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM furstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string boo = (dr["Boocase"].ToString());
                    eeee = Convert.ToInt32(tbx10.Text);
                    furn[5] = (eeee * Convert.ToInt64(boo));
                }
                conn.Close();
            }
           

            int ffff;
            if (cbk7.Checked == false)
            {
                ffff = 0;
            }
            else
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM furstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string coa = (dr["Coatrack"].ToString());
                    ffff = Convert.ToInt32(tbx11.Text);
                    furn[6] = (ffff * Convert.ToInt64(coa));
                }
                conn.Close();
            }
            

            int gggg;
            if (cbk8.Checked == false)
            {
                gggg = 0;
            }
            else
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM furstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string dra = (dr["Drawer"].ToString());
                    gggg = Convert.ToInt32(tbx12.Text);
                    furn[7] = (gggg * Convert.ToInt64(dra));
                }
                conn.Close();
            }
           

            int hhhh;
            if (cbk9.Checked == false)
            {
                hhhh = 0;
            }
            else
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM furstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string cur = (dr["Curtains"].ToString());
                    hhhh = Convert.ToInt32(tbx13.Text);
                    furn[8] = (hhhh * Convert.ToInt64(cur));
                }
                conn.Close();
            }
            

            double isubtext = furn[0] + furn[1] + furn[2] + furn[3] + furn[4] + furn[5] + furn[6] + furn[7] + furn[8];
            tbx1.Text = Convert.ToString("Rs " + " " + isubtext);
            double i, j;
            i = 0.05 * isubtext;
            tbx2.Text = Convert.ToString("Rs " + " " + i);
            j = isubtext - i;
            tbx3.Text = Convert.ToString("Rs " + " " + j);

            receipt.Clear();
            receipt.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            receipt.AppendText("                  HASEEB AND SONS STORE" + Environment.NewLine);
            receipt.AppendText("                   " + dateTimePicker1.Text + "  ");
            receipt.AppendText("CUSTOMER NAME: " + textBox1.Text + Environment.NewLine);
            receipt.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            receipt.AppendText("Item                Price of product           Quantity" + Environment.NewLine);
            receipt.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            if (cbk1.Checked == true)
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM furstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string sof = (dr["Sofa"].ToString());
                    receipt.AppendText("Mobile                         " + sof + "\t            " + tbx5.Text + Environment.NewLine);
                }
                conn.Close();
            }
            if (cbk2.Checked == true)
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM furstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string cup = (dr["Cupboard"].ToString());
                    receipt.AppendText("Cupboard                      " + cup + "\t            " + tbx6.Text + Environment.NewLine);
                }
                conn.Close();
            }
            if (cbk3.Checked == true)
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM furstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string tab = (dr["Tables"].ToString());
                    receipt.AppendText("Tables                          " + tab + "\t            " + tbx7.Text + Environment.NewLine);
                }
                conn.Close();
            }
            if (cbk4.Checked == true)
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM furstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string ch = (dr["Chairs"].ToString());
                    receipt.AppendText("Chairs                          " + ch + "\t            " + tbx8.Text + Environment.NewLine);
                }
                conn.Close();
            }
            if (cbk5.Checked == true)
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM furstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string be = (dr["Bed"].ToString());
                    receipt.AppendText("Bed                              " + be + "\t            " + tbx9.Text + Environment.NewLine);
                }
                conn.Close();
            }
            if (cbk6.Checked == true)
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM furstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string Boo = (dr["Boocase"].ToString());
                    receipt.AppendText("Bookcase                     " + Boo + "\t            " + tbx10.Text + Environment.NewLine);
                }
                conn.Close();
            }
            if (cbk7.Checked == true)
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM furstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string coa = (dr["Coatrack"].ToString());
                    receipt.AppendText("Coatrack                     " + coa + "\t            " + tbx11.Text + Environment.NewLine);
                }
                conn.Close();
            }
            if (cbk8.Checked == true)
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM furstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string dra = (dr["Drawer"].ToString());
                    receipt.AppendText("Drawer                       " + dra + "\t            " + tbx12.Text + Environment.NewLine);
                }
                conn.Close();
            }
            if (cbk9.Checked == true)
            {
                conn.Open();
                SqlCommand sc = new SqlCommand("SELECT * FROM furstk", conn);
                sc.ExecuteNonQuery();
                SqlDataReader dr = sc.ExecuteReader();
                if (dr.Read())
                {
                    string cur = (dr["Curtains"].ToString());
                    receipt.AppendText("Curtains                       " + cur + "\t            " + tbx13.Text + Environment.NewLine);
                }
                conn.Close();
            }
            receipt.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            receipt.AppendText("Total : " + "\t\t" + tbx1.Text + Environment.NewLine);
            receipt.AppendText("Discount: " + "\t\t" + tbx2.Text + Environment.NewLine);
            receipt.AppendText("Final Amount" + "\t" + tbx3.Text + Environment.NewLine);
            receipt.AppendText("------------------------THANK YOU------------------------" + Environment.NewLine);


           

        }

        private void button4_Click(object sender, EventArgs e)
        {
            const string message = "Do You Want to Exit ?";
            const string closing = "Closing Program";
            var result = MessageBox.Show(message, closing, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void tbx5_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tbx6_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tbx7_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tbx8_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tbx9_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tbx10_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tbx11_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tbx12_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void tbx13_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void label15_Click(object sender, EventArgs e)
        {
            this.Hide();
            furniviewdata sn = new furniviewdata();
            sn.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Basit Mashkoor\Desktop\inventory\db\looooogindb.mdf;Integrated Security=True;Connect Timeout=30");
                conn.Open();
                SqlCommand sw = new SqlCommand("INSERT INTO frni(Name,Sofa,Cupboard,Tables,Chairs,Bed,Bookcase,Coatrack,Drawer,Curtains,Total,Discount,Final_Amount,Date) VALUES ('" + textBox1.Text + "','" + tbx5.Text + "','" + tbx6.Text + "','" + tbx7.Text + "','" + tbx8.Text + "','" + tbx9.Text + "','" + tbx10.Text + "','" + tbx11.Text + "','" + tbx12.Text + "','" + tbx13.Text + "','" + tbx1.Text + "','" + tbx2.Text + "','" + tbx3.Text + "','" + dateTimePicker1.Text + "')", conn);
                if (sw.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("DATA IS INSERTED SUCCESSFULLY!!!!");
                }

                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label17_Click(object sender, EventArgs e)
        {
            this.Hide();
            furniup sl = new furniup();
            sl.Show();
        }
    }
}
