﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace inventory
{
    public partial class utility : Form
    {
        public utility()
        {
            InitializeComponent();
        }
        private void ResetTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Text = " ";
                    else
                        func(control.Controls);
            };
            func(Controls);
        }

        private void ResetcheckBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is CheckBox)
                        (control as CheckBox).Checked = false;
                    else
                        func(control.Controls);
            };
            func(Controls);
        }

        private void EnableTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Enabled = false;
                    else
                        func(control.Controls);
            };
            func(Controls);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 j = new Form2();
            j.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ResetTextBoxes();
            ResetcheckBoxes();
            rpc.Clear();
        }

        private void c1_CheckedChanged(object sender, EventArgs e)
        {
            if(c1.Checked == true)
            {
                t5.Enabled = true;
                t5.Text = "";
                t5.Focus();

            }
            else
            {
                t5.Enabled = false;
                t5.Text = "";
            }
        }

        private void c2_CheckedChanged(object sender, EventArgs e)
        {
            if(c2.Checked == true)
            {
                t6.Enabled = true;
                t6.Text = "";
                t6.Focus();

            }
            else
            {
                t6.Enabled = false;
                t6.Text = "";
            }
        }

        private void c3_CheckedChanged(object sender, EventArgs e)
        {
            if (c3.Checked == true)
            {
                t7.Enabled = true;
                t7.Text = "";
                t7.Focus();

            }
            else
            {
                t7.Enabled = false;
                t7.Text = "";
            }
        }

        private void c4_CheckedChanged(object sender, EventArgs e)
        {
            if (c4.Checked == true)
            {
                t8.Enabled = true;
                t8.Text = "";
                t8.Focus();

            }
            else
            {
                t8.Enabled = false;
                t8.Text = "";
            }
        }

        private void c5_CheckedChanged(object sender, EventArgs e)
        {
            if (c5.Checked == true)
            {
                t9.Enabled = true;
                t9.Text = "";
                t9.Focus();

            }
            else
            {
                t9.Enabled = false;
                t9.Text = "";
            }
        }

        private void c6_CheckedChanged(object sender, EventArgs e)
        {
            if (c6.Checked == true)
            {
                t10.Enabled = true;
                t10.Text = "";
                t10.Focus();

            }
            else
            {
                t10.Enabled = false;
                t10.Text = "";
            }
        }

        private void c7_CheckedChanged(object sender, EventArgs e)
        {
            if (c7.Checked == true)
            {
                t11.Enabled = true;
                t11.Text = "";
                t11.Focus();

            }
            else
            {
                t11.Enabled = false;
                t11.Text = "";
            }
        }

        private void c8_CheckedChanged(object sender, EventArgs e)
        {
            if (c8.Checked == true)
            {
                t12.Enabled = true;
                t12.Text = "";
                t12.Focus();

            }
            else
            {
                t12.Enabled = false;
                t12.Text = "";
            }
        }

        private void c9_CheckedChanged(object sender, EventArgs e)
        {
            if (c9.Checked == true)
            {
                t13.Enabled = true;
                t13.Text = "";
                t13.Focus();

            }
            else
            {
                t13.Enabled = false;
                t13.Text = "";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double[] utili = new double[9];

            int quanolp;
            if (c1.Checked == false)
            {
                quanolp = 0;
            }
            else
            {
                quanolp = Convert.ToInt32(t5.Text);
            }
            utili[0] = (quanolp * 220);

            int aaaa;
            if (c2.Checked == false)
            {
                aaaa = 0;
            }
            else
            {
                aaaa = Convert.ToInt32(t6.Text);
            }
            utili[1] = (aaaa * 380);

            int bbbb;
            if (c3.Checked == false)
            {
                bbbb = 0;
            }
            else
            {
                bbbb = Convert.ToInt32(t7.Text);
            }
            utili[2] = (bbbb * 150);

            int cccc;
            if (c4.Checked == false)
            {
                cccc = 0;
            }
            else
            {
                cccc = Convert.ToInt32(t8.Text);
            }
            utili[3] = (cccc * 2500);

            int dddd;
            if (c5.Checked == false)
            {
                dddd = 0;
            }
            else
            {
                dddd = Convert.ToInt32(t9.Text);
            }
            utili[4] = (dddd * 500);

            int eeee;
            if (c6.Checked == false)
            {
                eeee = 0;
            }
            else
            {
                eeee = Convert.ToInt32(t10.Text);
            }
            utili[5] = (eeee * 15);

            int ffff;
            if (c7.Checked == false)
            {
                ffff = 0;
            }
            else
            {
                ffff = Convert.ToInt32(t11.Text);
            }
            utili[6] = (ffff * 300);

            int gggg;
            if (c8.Checked == false)
            {
                gggg = 0;
            }
            else
            {
                gggg = Convert.ToInt32(t12.Text);
            }
            utili[7] = (gggg * 800);

            int hhhh;
            if (c9.Checked == false)
            {
                hhhh = 0;
            }
            else
            {
                hhhh = Convert.ToInt32(t13.Text);
            }
            utili[8] = (hhhh * 20);

            double isubtext = utili[0] + utili[1] + utili[2] + utili[3] + utili[4] + utili[5] + utili[6] + utili[7] + utili[8];
            t1.Text = Convert.ToString("Rs " + " " + isubtext);
            double i, j;
            i = 0.05 * isubtext;
            t2.Text = Convert.ToString("Rs " + " " + i);
            j = isubtext - i;
            t3.Text = Convert.ToString("Rs " + " " + j);

            rpc.Clear();
            rpc.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            rpc.AppendText("                  HASEEB AND SONS STORE" + Environment.NewLine);
            rpc.AppendText("                   "+dateTimePicker1.Text+"  ");
            rpc.AppendText("CUSTOMER NAME: " + textBox1.Text + Environment.NewLine);
            rpc.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            rpc.AppendText("Item                Price of product           Quantity" + Environment.NewLine);
            rpc.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            if (c1.Checked == true)
                rpc.AppendText("Rice" + "    \t\t220" + "\t            " + t5.Text + Environment.NewLine);
            if (c2.Checked == true)
                rpc.AppendText("Oil" + "\t\t380" + "\t            " + t6.Text + Environment.NewLine);
            if (c3.Checked == true)
                rpc.AppendText("Vegetables" + "\t150" + "\t            " + t7.Text + Environment.NewLine);
            if (c4.Checked == true)
                rpc.AppendText("Dry fruits" + "\t\t2500" + "\t            " + t8.Text + Environment.NewLine);
            if (c5.Checked == true)
                rpc.AppendText("Fruits  " + "\t\t500" + "\t            " + t9.Text + Environment.NewLine);
            if (c6.Checked == true)
                rpc.AppendText("Eggs" + "\t\t15" + "\t            " + t10.Text + Environment.NewLine);
            if (c7.Checked == true)
                rpc.AppendText("Detergent" + "\t\t300" + "\t            " + t11.Text + Environment.NewLine);
            if (c8.Checked == true)
                rpc.AppendText("Cake" + "  \t\t800" + "\t            " + t12.Text + Environment.NewLine);
            if (c9.Checked == true)
                rpc.AppendText("Biscuits" + "\t\t20" + "\t            " + t13.Text + Environment.NewLine);
            rpc.AppendText("-------------------------------------------------------------------" + Environment.NewLine);
            rpc.AppendText("Total : " + "\t\t" + t1.Text + Environment.NewLine);
            rpc.AppendText("Discount: " + "\t\t" + t2.Text + Environment.NewLine);
            rpc.AppendText("Final Amount" + "\t" + t3.Text + Environment.NewLine);
            rpc.AppendText("------------------------THANK YOU------------------------" + Environment.NewLine);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            const string message = "Do You Want to Exit ?";
            const string closing = "Closing Program";
            var result = MessageBox.Show(message, closing, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void t5_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void t6_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void t7_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void t8_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void t9_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void t10_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void t11_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void t12_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void t13_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("PLEASE ENTER ANY NUMBER!!!!!!");
            }
        }

        private void label15_Click(object sender, EventArgs e)
        {
            this.Hide();
            utiliviewdata sb = new utiliviewdata();
            sb.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Basit Mashkoor\Desktop\inventory\db\looooogindb.mdf;Integrated Security=True;Connect Timeout=30");
                conn.Open();
                SqlCommand sw = new SqlCommand("INSERT INTO util(Name,Rice,Oil,Vegetables,Dry_Fruits,Fruits,Eggs,Detergent,Cakes,Biscuits,Total,Discount,Final_Amount,Date) VALUES ('" + textBox1.Text + "','" + t5.Text + "','" + t6.Text + "','" + t7.Text + "','" + t8.Text + "','" + t9.Text + "','" + t10.Text + "','" + t11.Text + "','" + t12.Text + "','" + t13.Text + "','" + t1.Text + "','" + t2.Text + "','" + t3.Text + "','" + dateTimePicker1.Text + "')", conn);
                if (sw.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("DATA IS INSERTED SUCCESSFULLY!!!!");
                }

                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
